<template>
  <div>
    <h1>歌手</h1>
  </div>
</template>

<script>
export default {
  name: "Singer",
  data() {
    return {};
  },
  components: {},
  created() {},
  mounted() {},
  methods: {},
  computed: {}
};
</script>

<style scoped lang="scss">
</style>
