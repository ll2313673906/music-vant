<template>
  <div>
    <h1>排行榜</h1>
  </div>
</template>

<script>
export default {
  name: "Ranking",
  data() {
    return {};
  },
  components: {},
  created() {},
  mounted() {},
  methods: {},
  computed: {}
};
</script>

<style scoped lang="scss">
</style>
