<template>
  <div>
    <van-tabbar>
      <van-tabbar-item icon="https://i.loli.net/2020/05/11/ryQLOTAgjVkluNC.png">标签</van-tabbar-item>
      <van-tabbar-item icon="https://i.loli.net/2020/05/11/ryQLOTAgjVkluNC.png">标签</van-tabbar-item>
      <van-tabbar-item icon="https://i.loli.net/2020/05/11/ryQLOTAgjVkluNC.png">标签</van-tabbar-item>
    </van-tabbar>

  </div>
</template>

<script>
export default {
  name: "Footer",
  data() {
    return {};
  }
};
</script>

<style scoped lang="scss">
</style>
