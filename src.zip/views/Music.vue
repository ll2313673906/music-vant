<template>
  <div>
    <h1>恭喜登录成功！！！</h1>
  </div>
</template>

<script>
export default {
  name: "Music",
  data() {
    return {};
  },
  components: {}
};
</script>

<style scoped lang="scss">
</style>
